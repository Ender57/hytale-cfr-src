/*
 * Decompiled with CFR 0.152.
 */
package com.hypixel.hytale.builtin.asseteditor.data;

public enum AssetState {
    CHANGED,
    NEW,
    DELETED;

}

