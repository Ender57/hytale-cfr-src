/*
 * Decompiled with CFR 0.152.
 */
package com.hypixel.hytale.builtin.buildertools;

public class PrefabCopyException
extends Exception {
    public PrefabCopyException(String message) {
        super(message);
    }
}

