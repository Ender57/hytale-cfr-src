/*
 * Decompiled with CFR 0.152.
 */
package com.hypixel.hytale.builtin.buildertools.scriptedbrushes.operations.system;

import com.hypixel.hytale.builtin.buildertools.scriptedbrushes.operations.system.BrushOperation;

public abstract class GlobalBrushOperation
extends BrushOperation {
    public GlobalBrushOperation(String name, String description) {
        super(name, description);
    }
}

