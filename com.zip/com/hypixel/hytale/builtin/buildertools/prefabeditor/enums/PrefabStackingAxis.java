/*
 * Decompiled with CFR 0.152.
 */
package com.hypixel.hytale.builtin.buildertools.prefabeditor.enums;

public enum PrefabStackingAxis {
    X,
    Z;

}

