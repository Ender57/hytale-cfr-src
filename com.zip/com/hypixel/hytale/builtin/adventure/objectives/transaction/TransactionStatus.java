/*
 * Decompiled with CFR 0.152.
 */
package com.hypixel.hytale.builtin.adventure.objectives.transaction;

enum TransactionStatus {
    SUCCESS,
    FAIL;

}

