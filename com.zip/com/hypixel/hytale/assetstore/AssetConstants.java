/*
 * Decompiled with CFR 0.152.
 */
package com.hypixel.hytale.assetstore;

public class AssetConstants {
    public static final int EXPECTED_CHILDREN_PER_ASSET = 3;
    public static final int EXPECTED_ASSETS_PER_PATH = 1;
    public static final int EXPECTED_VALUES_PER_TAG = 3;
    public static final int EXPECTED_ASSETS_PER_TAG = 3;
}

