/*
 * Decompiled with CFR 0.152.
 */
package com.hypixel.hytale.assetstore;

public interface JsonAsset<K> {
    public K getId();
}

